function ReturnArrayCountGreaterThanY(arr, y) {
    var numCount = 0
    var values = []
    for (i = 0; i < arr.length; i++) {
        if (arr[i] > y) {
            numCount = numCount + 1;
            values.push(arr[i]);
        }
    }
    console.log(values);
}
ReturnArrayCountGreaterThanY(arr, y);

function PrintMaxMinAverageArrayVals(arr) {
    var min = Infinity;
    var max = -Infinity;
    var sum = 0;
    for (var i = 0; i < arr.length; i++) {
        sum = sum + arr[i];
        if (arr[i] > max) {
            max = arr[i];
        } else if (arr[i] < min) {
            min = arr[i];
        }
    }
    var average = sum / arr.length;
    console.log('Min: ' + min + ' Max: ' + max + ' Average: ' + average)
}
PrintMaxMinAverageArrayVals(arr);


function SwapStringForArrayNegativeVals(x) {
    var zero = 0;
    for (var i = 0; i < x.length; i++) {
        if (x[i] < zero) {
            x[i] = 'Dojo';
        }
    }
    console.log(x);
    return x;
}
x = [1, 2, -3, -5, 5];
SwapStringForArrayNegativeVals(x);

4. Given array, and indices start and end, remove vals in that index range, working in -place(hence shortening the array).For example, removeVals([20, 30, 40, 50, 60, 70], 2, 4) should
return [20, 30, 70].

function removeVals(arr, start, end) {

    arr.splice(start, (end - start + 1))
    return arr;
}