Print 1 to x
function printUpTo(x) {
    for (var i = 1; i <= 1000; i += 2) {
        console.log(i);
    }
}
printUpTo(1000);
y = printUpTo(-10);
console.log(y);

PrintSum
function printSum(x) {
    var sum = 0;
    for (var i = 0; i <= 255; i++) {
        sum = sum + i;
        console.log(i + ' | CURRENT SUM: ' + sum);
    }
    return sum
}
y = printSum(255) // should print all the integers from 0 to 255 and with each integer print the sum so far.
console.log(y) // should print 32640

PrintSumArr
function printSumArray(x){
    var sum = 0;
    for(var i=0; i<x.length; i++) {
    sum = sum + x[i];
  }
    console.log(sum);
    return sum
}
console.log( printSumArray([1,2,3]) );