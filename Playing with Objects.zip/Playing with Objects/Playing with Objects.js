// Playing with Objects
// Charles Edwards III

// Objectives

// Practice iterating through an array of objects/dictionaries.
// Imagine that you are given an array of objects.  For example,

var users = [{ name: "Michael", age: 37 }, { name: "John", age: 30 }, { name: "David", age: 27 }];

// How would you print/log John's age?
// How would you print/log the name of the first object?
// How would you print/log the name and age of each user using a for loop?  Your output should look something like this



// Solution
// How would you print/log John's age?
// How would you print/log the name of the first object?
var michael = {
    name: 'Micheal',
    age: 37,
}
var john = {
    name: 'John',
    age: 30,
}
var david = {
    name: 'David',
    age: 27,
}
console.log(john.age)
console.log(michael.name)

// How would you print/log the name and age of each user using a for loop?  Your output should look something like this

var person = { fname: "michael", age: 37 };

var text1 = "";
var x;
for (x in person) {
    text1 += person[x];
}
console.log(text1);

var person2 = { fname: "John", age: 30 };

var text2 = "";
var x;
for (x in person2) {
    text2 += person2[x];
}
console.log(text2);

var person3 = { fname: "david", age: 27 };

var text3 = "";
var x;
for (x in person3) {
    text3 += person3[x];
}
console.log(text3);
Michael - 37
John - 30
David - 27